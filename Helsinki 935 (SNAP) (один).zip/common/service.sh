#!/system/bin/sh
MODDIR=${0%/*}

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 60

####################################
# Services
####################################
su -c 'stop logcat logcatd logd tcpdump cnss_diag statsd traced idd- logreader idd- logreadermain perfd stats companion auditd dumpstate aplogd'

####################################
# System Log
####################################
su -c "pm uninstall -k --user 0 com.android.traceur"

####################################
# Kernel Debugging (thx to KTSR)
####################################
for i in "debug_mask" "log_level*" "debug_level*" "*debug_mode" "edac_mc_log*" "enable_event_log" "*log_level*" "*log_ue*" "*log_ce*" "log_ecn_error" "snapshot_crashdumper" "seclog*" "compat-log" "*log_enabled" "tracing_on" "mballoc_debug"; do
    for o in $(find /sys/ -type f -name "$i"); do
        echo '0' > "$o"
    done
done

####################################
# CRC
####################################
for parameters in /sys/module/mmc_core/parameters/*; do echo '0' > "$parameters/use_spi_crc" && echo '0' > "$parameters/removable" && echo '0' > "$parameters/crc"; done.

####################################
# Excessive Log
####################################
echo 'N' > /sys/kernel/debug/debug_enabled &&
echo 'N' > /sys/kernel/debug/sched_debug &&
echo '0' > /sys/kernel/tracing/tracing_on &&
echo 'Y' > /sys/kernel/debug/npu/sys_cache_disable &&
echo '0' > /sys/kernel/debug/sde_rotator0/disable_syscache &&
echo '0' > /sys/kernel/debug/WMI0/wmi_enable &&
echo '0' > /sys/kernel/debug/sde_rotator0/evtlog/enable &&
echo '0' > /sys/kernel/debug/dri/0/debug/enable &&
echo '0' > /sys/kernel/debug/rpm_log &&
echo '0' > /sys/kernel/sched/gentle_fair_sleepers

####################################
# Kernel Panic
####################################
for kernel in /proc/sys/kernel/* /sys/module/kernel/parameters/*; do
        case $(basename "$kernel") in
            "panic" | "panic_on_oops" | "panic_on_warn" | "panic_on_rcu_stall" | "softlockup_panic" | "nmi_watchdog" | "pause_on_oops")
                echo '0' > "$kernel"
                ;;
    esac
done

####################################
# Printk (thx to KNTD-reborn)
####################################
echo '0 0 0 0' > /proc/sys/kernel/printk && \
echo '0' > /sys/module/printk/parameters/cpu && \
echo '1' > /sys/module/printk/parameters/console_suspend && \
echo '0' > /sys/kernel/printk_mode/printk_mode && \
echo '1' > /sys/module/printk/parameters/ignore_loglevel && \
echo '0' > /sys/module/printk/parameters/pid && \
echo '0' > /sys/module/printk/parameters/time && \
echo '0' > /sys/module/printk/parameters/printk_ratelimit

####################################
# Ramdumps
####################################
for parameters in /sys/module/subsystem_restart/parameters; do
    echo '0' > "$parameters/enable_ramdumps"
    echo '0' > "$parameters/enable_mini_ramdumps"
done

####################################
# Touchboost
####################################
echo '0' > '/sys/module/msm_performance/parameters/touchboost'
echo '0' > '/sys/power/pnpmgr/touch_boost'

####################################
# Adreno Idler
####################################
echo '0' > '/sys/module/adreno_idler/parameters/adreno_idler_active'

####################################
# Disable Sched
####################################
echo '0' > '/proc/sys/kernel/sched_boost'
echo '0' > '/proc/sys/kernel/sched_schedstats'

####################################
# Logs Init.rc
####################################
sed -i -e 's/service logd/service logd disabled/g' -e 's/on property:sys.log.redirect-stdio=1/on property:sys.log.redirect-stdio=0/g' -e 's/setprop persist.service.logging.enable 1/# setprop persist.service.logging.enable 1/g' /system/etc/init/rc

####################################
# More Services
####################################
su -c 'pm disable com.google.android.gms/.chimera.GmsIntentOperationService
pm disable com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable com.google.android.apps.wellbeing/.powerstate.impl.PowerStateJobService
pm disable com.google.android.apps.wellbeing/.home.BottomNavActivity
pm disable com.google.android.apps.wellbeing/.notifications.NotificationsService
pm disable com.google.android.apps.wellbeing/.notification.NotificationJobService
pm disable com.google.android.apps.wellbeing/.onboarding.OnboardingService
pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable com.google.android.apps.wellbeing/androidx.work.impl.background.systemjob.SystemJobService
pm disable com.google.android.gms/com.google.android.gms.ads.identifier.service.AdvertisingldService
pm disable com.google.android.gms/com.google.android.gms.ads.settings.AdsSettingsActivity
pm disable com.google.android.gms/com.google.android.gms.ads.identifier.service.AdvertisingldNotificationService
pm disable com.google.android.gms/com.google.android.gms.analytics.internal.PlayLogReportingService
pm disable com.google.android.gms/com.google.android.gms.nearby.bootstrap.service.NearbyBootstrapService
pm disable com.google.android.gms/NearbyMessagesService
pm disable com.google.android.gms/com.google.android.gms.nearby.connection.service.NearbyConnectionsAndroidService
pm disable com.google.android.gms/com.google.android.gms.lockbox.LockboxService
pm disable com.google.android.gms/.measurement.PackageMeasurementTaskService
pm disable com.google.android.gms/com.google.android.gms.auth.trustagent.GoogleTrustAgent
pm disable com.google.android.gms/com.google.android.gms.ads.cache.CacheBrokerService
pm disable com.google.android.gms/com.android.billingclient.api.ProxyBillingActivity
pm disable com.google.android.gms/com.google.location.nearby.direct.service.NearbyDirectService
pm disable com.google.android.gms/com.google.android.gms.ads.config.FlagsReceiver
pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsService
pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsReceiver
pm disable com.google.android.gms/com.google.android.gms.analytics.service.AnalyticsService
pm disable com.google.android.gms/com.google.android.gms.measurement.AppMeasurementReceiver
pm disable com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementReceiver
pm disable com.google.android.gms/.backup.stats.BackupStatsService
pm disable com.google.android.gms/.common.stats.StatsUploadService
pm disable com.google.android.gms/.common.stats.net.NetworkReportService
pm disable com.google.android.gms/.stats.PlatformStatsCollectorService
pm disable com.google.android.gms/.stats.service.DropBoxEntryAddedService
pm disable com.android.vending/com.google.android.gms.measurement.AppMeasurementJobService
pm disable com.android.vending/com.google.android.gms.measurement.AppMeasurementReceiver
pm disable com.instagram.android/com.instagram.analytics.uploadscheduler.AnalyticsUploadAlarmReceiver
pm disable com.instagram.android/com.instagram.common.analytics.phoneid.InstagramPhoneIdRequestReceiver
pm disable com.instagram.android/com.instagram.common.analytics.phoneid.InstagramPhoneIdRequestReceiver
pm disable com.instagram.android/com.instagram.analytics.uploadscheduler.AnalyticsUploadAlarmReceiver
pm disable com.instagram.android/com.facebook.analytics2.logger.AlarmBasedUploadService
pm disable com.instagram.android/com.facebook.analytics2.logger.LollipopUploadService
pm disable com.instagram.android/com.facebook.analytics2.logger.GooglePlayUploadService
pm disable com.instagram.android/com.facebook.analytics2.logger.HighPriUploadRetryReceiver
pm disable com.instagram.android/com.facebook.analytics.appstatelogger.AppStateBroadcastReceiver
pm disable com.instagram.android/com.facebook.analytics.appstatelogger.AppStateIntentService
pm disable com.android.vending/com.google.android.gms.measurement.AppMeasurementService
pm disable com.whatsapp/com.google.android.gms.analytics.AnalyticsJobService
pm disable com.whatsapp/com.google.android.gms.analytics.AnalyticsReceiver
pm disable com.whatsapp/com.google.android.gms.analytics.AnalyticsService
pm disable com.whatsapp/androidx.work.impl.diagnostics.DiagnosticsReceiver
pm disable com.whatsapp/com.whatsapp.payments.receiver.IndiaUpiPayIntentReceiverActivity
pm disable com.whatsapp/com.google.android.gms.auth.api.signin.RevocationBoundService
pm disable com.whatsapp/com.whatsapp.instrumentation.notification.DelayedNotificationReceiver'

####################################
# Administradores de Dispositivos
####################################
for user_id in $(ls $USER_DIR); do
  for pacote in "${GC[@]}"; do
     pm disable --user $user_id "$GMS/$GMS.$pacote" &> $NLL
  done
done

####################################
# Activity Manager (thx to crokrammgmtfix)
####################################
su -c /system/bin/device_config set_sync_disabled_for_tests persistent
su -c /system/bin/device_config put activity_manager max_phantom_processes 2147483647
su -c /system/bin/device_config put global settings_enable_monitor_phantom_procs false


####################################
# Virtual Memory
####################################
for virtual_memory in /proc/sys/vm; do echo '20' > "$virtual_memory/stat_interval" && echo '0' > "$virtual_memory/page-cluster" && echo '0' > "$virtual_memory/panic_on_oom"; done.

####################################
# LMK
####################################
echo "0" > '/sys/module/lowmemorykiller/parameters/debug_level'

####################################
# LPM Levels
####################################
for parameters in /sys/module/lpm_levels/parameters/*; do echo '0' > "$parameters/sleep_disabled" && echo '0' > "$parameters/lpm_prediction" && echo '0' > "$parameters/lpm_ipi_prediction"; done.

####################################
# File System
####################################
for fs in /proc/sys/fs; do echo '0' > "$fs/dir-notify-enable" && echo '0' > "$fs/by-name/userdata/iostat_enable"; done.

####################################
# I/O
####################################
for queue in /sys/block/*/queue; do echo -e '0\n0\n128\n0\n0\n64\n1\n0\n0\n0\n0\n1' > "$queue/iostats $queue/rotational $queue/read_ahead_kb $queue/add_random $queue/nomerges $queue/nr_requests $queue/rq_affinity $queue/iosched/slice_idle $queue/iosched/slice_idle_us $queue/iosched/group_idle $queue/iosched/group_idle_us $queue/iosched/back_seek_penalty"; done

####################################
# GPU
####################################
for gpu in /sys/class/kgsl/kgsl-3d0; do echo '0' > "$gpu/adrenoboost"; echo '0' > "$gpu/devfreq/adrenoboost"; echo 'N' > "$gpu/adreno_idler_active"; echo '0' > "$gpu/throttling"; echo '0' > "$gpu/thermal_pwrlevel"; echo '0' > "$gpu/perfcounter"; echo '0' > "$gpu/max_pwrlevel"; echo '0' > "$gpu/popp"; echo '0' > "$gpu/pwrnap"; done.

####################################
# IPV4
####################################
for ipv4 in /proc/sys/net/ipv4; do echo '3' > "$ipv4/tcp_fastopen"; echo '1' > "$ipv4/tcp_ecn"; echo '0' > "$ipv4/tcp_syncookies"; done.

####################################
# Battery
####################################
for sys in /sys; do echo 'Y' > "$sys/module/battery_saver/parameters/enabled"; echo 'Y' > "$sys/module/workqueue/parameters/power_efficient"; echo '1' > "$sys/devices/system/cpu/sched_mc_power_savings"; echo 'deep' > "$sys/power/mem_sleep"; done.

####################################
# Miscellaneous
####################################
for kernel in /proc/sys/kernel; do echo '6000000' > "$kernel/sched_latency_ns"; echo '5000000' > "$kernel/sched_migration_cost_ns"; echo '0' > "$kernel/sched_child_runs_first"; echo '1' > "$kernel/sched_autogroup_enabled"; echo '0' > "$kernel/sched_tunable_scaling"; echo '0' > "$kernel/hung_task_timeout_secs"; echo '20' > "$kernel/perf_cpu_time_max_percent"; echo '0' > "$kernel/timer_migration"; done

####################################
# Fstrim
####################################
su -c 'fstrim -v /data /system /cache /vendor /product /preload /metadata /odm /system_ext'

####################################
# Bye Script
####################################
su -lp 2000 -c "cmd notification post -S bigtext -t '⍣ Helsinki 935 ⍣' 'Tag' 'El módulo se aplicó correctamente, Ahora puedes disfrutar de una mejor experiencia 😁.'"

exit 0
